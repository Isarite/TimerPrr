package lt.isarite.timerpr;

public class Workout {
    String name = "name";

}
