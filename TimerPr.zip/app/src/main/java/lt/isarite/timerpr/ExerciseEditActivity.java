package lt.isarite.timerpr;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ExerciseEditActivity extends AppCompatActivity {

    String exercise;
    String muscles;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_edit);
    }
}
